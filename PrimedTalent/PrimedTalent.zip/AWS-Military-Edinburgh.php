<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AWS re/Start | Primed Talent | Skill Development Program</title>
    <meta name="description" content="Together, AWS re/Start and Primed Talent Limited are excited to help individuals launch a career in cloud computing.  The 12-week program featuring real-world scenario-based learning, hands-on labs, and coursework is supported by professional mentors and accredited trainers">
    <meta name="keywords" content="Core IT areas for a Support / Operations such as Linux, Networking, Security, Python Programming, Database, Cloud Economics, Global Infrastructure, Elastic Load Balancing, Amazon CloudWatch, Auto Scaling, Cloud Architecting & Security, Tooling-and-Automation, Computing-Servers, Scaling-and-Name-Resolution, Containers-and-Serverless, Networking, Monitoring-and-Security, job in Uk , job in united kingdom, redundant, cloud computing jobs, job opportunities, Amazon web service cloud certification, AWS re start program, resume and interview coaching, learning, hands-on labs, and coursework, AWS Cloud Practitioner Certification exam,restart or start your career, jobs after Retail, jobs after Hospitality, job in UK cities">
    <meta name="keywords" content="amazon web services,
job search,
cloud computing,
cloud technology,
amazon restart,
job opportunity,
amazon courses,
employment service,
jobs in uk,
Certification,
Job,
find a job,
aws certification,
amazon aws,
Iaas,
Certified,
job site,
aws account,
find jobs near me,
cloud computing services,
job listings near me,
amazon certification,
cloud service providers,
amazon web,
find me a job,
jobs in England,
aws developer certification,
aws certification training,
amazon training,
cloud certification,
career search,
amazon web services certification,
amazon web hosting,
jobs in the uk,
aws exam,
amazon fba course,
a job,
aws certified developer associate,
job search near me,
aws cloud computing,
amazon servers,
aws associate certification,
aws web hosting,
amazon ws,
amazon aws certification,
aws cloud certification,
find a job uk,
cloud networking,
cloud aws,
aws infrastructure,
aws service,
aws developer associate,
cloud it,
aws certification exam,
amazon cloud computing,
cloud solution,
aws web services,
amazon web services training,
iaas in cloud computing,
aws solutions,
aws iaas,
cloud computing technology,
amazon cloud server,
look for jobs,
work search,
job search site,
aws technology,
aws website hosting,
cloud computing platforms,
cloud based technology,
amazon aws training,
cloud computing providers,
azure cloud computing,
amazon web services pricing,
iaas providers,
aws website,
cloud iaas,
cloud infrastructure services,
cloud computing solutions,
aws amazon web services,
aws customer care,
aws app,
aws web server,
microsoft cloud computing,
cloud based server,
job job search,
amazon web services course,
cloud computing training,
jobs in united kingdom,
aws training cost,
cloud based computing,
amazon website hosting,
about aws,
best amazon fba course,
aws certification course,
iaas azure,
cloud computing infrastructure,
cloud industry,
aws compute services,
amazon aws account,
for jobs,
find employment,
job opportunities in uk,
cloud computing software,
aws customer service,
employment search,
cloud network technology,
amazon cloud hosting,
amazon aws services,
aws cloud training,
amazon data services,
amazon aws cloud,
explain cloud computing,
cloud computing system,
cloud computing company,
aws web hosting pricing,
cloud computing service providers,
aws web,
jobs in Britain,
best aws training,
amazon fba training,
job offers uk,
aws new services,
amazon web hosting pricing,
find work near me,
aws it,
cloud processing,
aws online,
aws core services,
infrastructure cloud,
cloud computing is,
job vacancies in uk,
amazon seller training,
aws a,
managed aws,
cloud computing environment,
amazon awa,
search work,
fba training,
companies using aws,
cloud computing industry,
amazon web services cloud,
concept of cloud computing,
amazon web services ec2,
aws web app,
aws cloud hosting,
aws training near me,
best cloud computing,
careers job,
amazon iaas,
hosting aws,
aws training courses,
job seekers jobs,
amazon cloud training,
aws business,
fba course,
microsoft azure cloud computing,
amazon web services cost,
infrastructure as a service in cloud computing,
cloud computing server,
amazon web services hosting,
amazon hosting server,
amazon web app,
understanding cloud computing,
best cloud computing service,
amazon cloud computing services,
aws class,
cloud computing business,
aws cloud infrastructure,
amazon seller course,
amazon web services cloud computing,
look for jobs near me,
cloud offerings,
web services in cloud computing,
amazon training course,
find me a job near me,
amazon web services account,
amazon aws cost,
amazon aws hosting,
aws training classes,
find a job site,
aws website builder,
aws is,
aws web hosting cost,
platform as a service in cloud computing,
find a work,
aws website hosting cost,
best fba course,
restart amazon fire,
cloud web services,
amazon web services customer service,
amazon class,
aws computing,
using aws,
it cloud solutions,
career job search,
cloud solutions company,
aws classes near me,
best aws course,
aws customer,
amazon web hosting cost,
cloud computing network,
explain the cloud,
ec2 web server,
aws web application,
amazon aws course,
amazon wbs,
awa amazon,
aws companies,
amazon ec2 server,
services provided by cloud computing,
web based computing,
top aws services,
tech data cloud,
amazon solutions,
aws cloud infrastructure service,
amazon cloud server price,
amazon cloud business,
aws cloud technology,
aws trainer,
iaas cloud services,
cloud computing strategy,
describe cloud computing,
aws infrastructure as a service,
amazon web server price,
best amazon course,
amazon website services,
best aws certification training,
ec2 iaas,
amazon free training,
best amazon fba courses,
aws cloud provider,
amazon seller training courses,
aws space,
in job search,
amazon web cloud,
cloud services in cloud computing,
amazon global infrastructure,
managed amazon web services,
aws certification near me,
cloud platform by amazon,
find careers,
cloud computing explanation,
job seeker employment,
amazon aws web hosting,
amazon ec2 in cloud computing,
cloud hosting server,
cloud it infrastructure,
amazon aws servers,
cloud technology services,
amazon cloud course,
amazon certification course,
aws cloud course,
aws cloud solutions,
cloud of technology,
find job seekers,
iaas infrastructure,
amazon computing,
aws certification classes,
cloud computing hosting,
aws was,
amazon web services developer,
computing as a service,
cloud in cloud computing,
cloud computing and its applications,
cloud server infrastructure,
microsoft cloud computing services,
iaas server,
aws iaas services,
amazon it services,
amazon web services iaas,
azure computing,
cloud infrastructure solutions,
on aws,
aws program,
best amazon fba training courses,
services provided by amazon web services,
aws network services,
aws as,
amazon certification training,
amazon web hosting services,
aws web development,
cloud server provider,
aws cloud computing courses,
aws certification training near me,
amazon aws developer,
amazon web services customer care,
aws ec2 web server,
cloud solution services,
azure cloud provider,
amazon ec2 iaas,
amazon web services server,
cloud and cloud computing,
amazon certification exam,
ec2 in cloud computing,
cloud computing data,
aws cloud computing services,
cloud and infrastructure,
amazon web services exam,
best aws services,
amazon web server cost,
aws in,
amazon web services company,
aws cloud environment,
best amazon selling course,
in cloud computing iaas is,
in aws,
amazon and aws,
cloud networking solutions,
amazon web services website hosting,
amazon webs services,
aws website monitoring,
amazon aws customer care,
the cloud technology,
amazon web services certification training,
amazon web services location,
amazon fba training course,
amazon cloud hosting price,
aws course near me,
cloud platform providers,
amazon web services web hosting,
amazon cloud certifications,
aws's,
amazon web certification,
aws like services,
cloud computing and services,
cloud computing details,
cloud computing programming,
aws cloud certification training,
aws certification training cost,
iaas hosting,
it cloud computing,
top amazon fba courses,
aws and cloud computing,
cloud computing and networking,
it as a service in cloud computing,
cloud based service providers,
amazon web space,
amazon aws app,
discuss cloud computing,
aws web application hosting,
cloud ec2,
azure cloud environment,
aws subscription management,
aws app hosting,
cloud based computing services,
amazon web server hosting,
aws certification classes near me,
companies on aws,
network as a service in cloud computing,
cloud tech company,
aws in it,
aws using companies,
amazon web services services,
amazon cloud solution,
aws by amazon,
amazon business training,
amazon cloud services certification,
amazon fba class,
aws cloud computing training,
web application hosting in the aws cloud,
cloud network infrastructure,
technologies for network based system in cloud computing,
amazon web services platform,
network and cloud technologies,
explain the concept of cloud computing,
amazon web services training cost,
amazon web services website,
amazon aws website hosting,
aws ec2 iaas,
amazon web services infrastructure,
amazon cloud computing course,
amazon web solutions,
aws app builder,
cloud technologies company,
amazon webs,
host website on aws ec2,
amazon cloud certification training,
aws elastic cloud compute,
amazon cloud developer,
amazon web servers location,
host website with aws,
amazon business course,
compute in aws,
amazon aws infrastructure,
amazon aws certification training,
amazon web services vpc,
aws web app hosting,
amazon web se,
different cloud technologies,
amazon ec2 web server,
cloud based programming,
amazon web services ec2 pricing,
amazon seller classes,
amazon cloud technology,
amazon cloud web hosting,
cloud related technologies,
hosting application in aws,
amazon training certification,
aws web server cost,
host a website in aws,
amazon web services hosting cost,
aws web page,
cost of hosting a website on aws,
fba training amazon,
amazon web development,
aws training price,
use aws to host website,
aws amazon uk,
cloud computing and its services,
amazon aws global server,
amazon web services hosting prices,
on and cloud tech,
s3 amazon web services,
companies using amazon web services,
web app amazon,
amazon aws cloud computing,
aws app services,
amazon aws website,
amazon classes near me,
amazon elastic cloud computing,
aws amazon web,
cloud data technologies,
technology behind cloud computing,
amazon and cloud computing,
amazon web services classes,
host web app on aws,
cloud computing aws course,
was aws,
amazon cloud development,
using aws for web hosting,
amazon elastic service,
using amazon web services,
iaas ec2,
aws for web developers,
amazon web services marketing,
amazon website hosting cost,
aws best training,
aws cloud compute,
aws network infrastructure,
amazon cloud services course,
course aws,
aws best course,
amazon web services app,
amazon web services free training,
amazon cloud iaas,
amazon web application,
best cloud technology,
ec2 website hosting,
cloud technology explained,
amazon aws platform,
cloud business technology,
building a website on aws,
service technology in cloud computing,
amazon fba best course,
training on aws,
programming amazon ec2,
amazon web services cloud platform,
ec2 website,
cloud computing platforms and technologies,
best courses for aws certification,
amazon aws iaas,
cloud based web services,
cloud technology providers,
cloud aws course,
on cloud tech,
amazon aws web hosting pricing,
aws course cost,
fba training courses,
aws hosting provider,
amazone cloud services,
amazon web services applications,
best amazon training course,
amazon cloud services training,
cloud and aws,
course amazon fba,
aws ws,
amazon courses fba,
clouds amazon,
amazon aws business,
amazons web services,
best aws certification course,
cloud computing in aws,
fba classes,
ec2 web hosting,
hosting a website with aws,
amazon app hosting,
amazon aws classes,
amazon web services monitoring,
cost of hosting website on aws,
cloud platform technologies,
programming amazon web services,
amazon aws web server,
cloud infrastructure technologies,
amazon amazon web services,
amazon web services certification course,
aws for,
amazon cloud management,
amazon cloud website hosting,
cloud services training,
amazon web services subscription,
web technology in cloud computing,
amazon web services home page,
aws training classes near me,
tech cloud solutions,
amazon web services server pricing,
aws course price,
web services and cloud computing,
amazon web training,
amazon web services service providers,
host a website aws,
amazon web based services,
amazon online server,
amazon cloud classes,
amazon managed hosting,
amazon website hosting price,
cost to host a website on aws,
aws based,
aws ec2 host website,
aws is a,
aws business training,
iaas services in aws,
aws core infrastructure and services,
host a website on aws ec2,
aws ec2 website,
aws for website,
aws certification learning,
amazon web services business,
amazon web services location of servers,
aws ec2 website hosting,
aws web server pricing,
web server in aws,
aws based applications,
top amazon courses,
amazon aws network,
aws web developer,
compute services aws,
understanding cloud technology,
amazing web services,
amazon aws management,
amazon cloud certification courses,
aws host web app,
hosting a web app on aws,
training aws certification,
aws w3,
amazon aws subscription,
aws and,
aws for web application,
amazon business class,
aws amazon developer,
cloud technology solution,
amazon ec2 certification,
amazon web services elastic compute cloud,
aws app hosting cost,
cost to host website on aws,
amazon and amazon web services,
amazon cloud network,
aws web server hosting,
aws web hosting services,
cloud computing using aws,
companies using aws cloud,
as aws,
amazon fba course near me,
amazon ec2 web hosting,
amazon aws global infrastructure,
web hosting aws cost,
aws compute ec2,
best course for amazon fba,
amazon application server,
best course for aws,
website with aws,
amazon aws compute,
amazon business aws,
aws cloud based,
amazon cloud computing pricing,
amazon aws in cloud computing,
amazon web services data,
amazon cloud data,
solutions aws,
aws certification course cost,
aws pricing for web hosting,
amazon cloud computing training,
aws to,
services on aws,
amazon cloud programming,
amazon web services website hosting cost,
aws as iaas,
amazon web services technology,
aws data as a service,
aws trainer certification,
best amazon fba training,
selling courses on amazon fba,
amazon ec2 website hosting,
aws for marketing,
customer service aws,
amazon cloud company,
amazon web services website builder,
aws on,
aws cloud certification course,
aws certification best training,
amazon web services integration,
aws web services training,
amazon web services networking,
best fba amazon course,
amazon cloud website,
amazon web services training near me,
aws services training,
amazon courses near me,
aws we,
amazon cloud online,
aws cloud classes,
aws certification course near me,
top aws courses,
amazon certificate courses,
amazon ec2 web services,
best course amazon fba,
amazon fba business course,
amazon cloud server hosting,
amazon learning courses,
amazon training classes,
amazon web services android,
amazon web services shares,
best training for aws,
top fba courses,
aws certification courses near me,

jobs in leeds,
jobs in Sheffield,
jobs in blackpool,
jobs in Edinburgh,
jobs in Newcastle,
job opportunities in uk,
cloud computing jobs in uk,
jobs in north east of England,
job offers in uk,
cloud jobs in Edinburgh,
jobs uk,
jobs in England,
jobs in the uk,
it jobs uk,
uk jobs for foreigners,
jobs in united kingdom,
jobs in england for foreigners,
uk job vacancies,
find job uk,
job vacancies Edinburgh,
job vacancies in Sheffield,
sheffield jobs today,
it jobs leeds,
it jobs Edinburgh,
leeds careers,
job vacancies leeds,
job vacancies blackpool,
work in Edinburgh,
it jobs Sheffield,
job opportunities in uk for foreigners,
vacancies in Edinburgh,
job search Edinburgh,
leeds vacancies,
job search leeds,
job opportunities in England,
work in leeds,
career opportunities uk,
jobs in sheffield uk,
job search Sheffield,
new jobs in Sheffield,
uk job hiring,
it jobs in England,
uk job openings,
job offers leeds,
england job vacancies,
united kingdom job hiring,
sheffield vacancies,
find job in England,
job search blackpool,
jobs available in Edinburgh,
find a job in Edinburgh,
job vacancies in uk for foreigners,
job offers Edinburgh,
jobs in blackpool area,
jobs available in uk,
new jobs in leeds,
work in blackpool,
careers Sheffield,
jobs available in Sheffield,
sheff jobs,
jobs at newcastle united,
latest sheffield jobs,
find a job Sheffield,
leeds it jobs,
jobs near leeds,
find a job blackpool,
jobs in blackpool uk,
careers in leeds,
new jobs Edinburgh,
jobs today leeds,
find a job in leeds,
all jobs in leeds,
jobs in edinburgh uk,
jobs available in blackpool,
job opportunities in Edinburgh,
blackpool vacancies,
jobs near Sheffield,
jobs near blackpool,
all jobs in blackpool,
jobs sheff,
jobs hiring in new castle,
jobs around leeds,
employment Edinburgh,
jobs in leeds area,
different jobs in leeds,
edinburgh employment,
new jobs blackpool,
work in edinburgh Scotland,
sheffield employment,
job opportunities in leeds,
latest jobs in leeds,
newcastle vacancy,
careers in Sheffield,
it jobs in edinburgh Scotland,
jobs near me leeds,
jobs edin,
jobs around Sheffield,
jobs in blackpool Lancashire,
it jobs north east England,
jobs near me Sheffield,
latest leeds jobs,
training courses in blackpool,
certifications in uk,
certifications in Edinburgh,
certifications in leeds,
cloud training in Sheffield,
cloud certifications in Newcastle,
amazon cloud certifications in uk,
aws courses uk,
">
    <!--Links-->
    <link rel="icon" href="Assets/Images/favicon.png" type="image/png" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous" />

    <link rel="stylesheet" href="css/styles.css" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet" />
    <!--End of links-->

    <!--Scripts-->

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <script src="https://kit.fontawesome.com/5e6131c1bd.js" crossorigin="anonymous"></script>
    <script src="javascript/main.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-177924410-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "UA-177924410-1");
    </script>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {},
            Tawk_LoadStart = new Date();
        (function() {
            var s1 = document.createElement("script"),
                s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/5f7c68374704467e89f517a4/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!--End of Tawk.to Script-->

    <style>
        .carbtn6 {
            border: 5px solid #2C446A;
        }

        @media(max-width:650px) {
            .carbtn6 {
                border: 5px solid #FF9900;
            }
        }
    </style>
</head>

<body style="overflow-x: hidden">
    <?php include "header.html" ?>

    <div class="text-on-img6">
        <div class="overlay-img">
            <img src="Assets/Images/awsm.jpg" class="img-fluid w-100 awscarousel awscarouselm" alt="" />
        </div>
        <!-- <h1 class="awstext0">AWS re/Start</h1> -->
        <img class="img-fluid awslogo" src="/Assets/Images/awslogo.png" alt="">
        <img class="img-fluid awslogo2 awslogom" src="/Assets/Images/awslogo2.png" alt="">
        <h1 class="awstext awstextm">Resettlement oppurtunity for service leavers. A career in Tech awaits you after completion of training with us!
        </h1>
        <div class="btn-container btn-containerm">
            <a href="AWS-Military-Yovill">
                <button class="btn carbtn carbtn1">Yovill<span>(*28-Jun-21)</span></button>
            </a>
            <a href="AWS-Military-Glasgow">
                <button class="btn carbtn carbtn2">Glasgow<span>(*19-Apr-21)</span></button>
            </a>
            <a href="AWS-Military-Dundee">
                <button class="btn carbtn carbtn3">Dundee<span>(*19-Apr-21)</span></button>
            </a>
            <a href="AWS-Military-Reading">
                <button class="btn carbtn carbtn4">Reading<span>(*16-Aug-21)</span></button><br>
            </a>
            <a href="AWS-Military-Southampton">
                <button class="btn carbtn carbtn5 carbtn5m">Southampton<span>(*28-Jun-21)</span></button>
            </a>
            <a href="AWS-Military-Edinburgh">
                <button class="btn carbtn carbtn6">Edinburgh<span>(*19-Apr-21)</span></button>
            </a>
            <a href="AWS-Military-Plymouth">
                <button class="btn carbtn carbtn7">Plymouth<span>(*28-Jun-21)</span></button><br>
            </a>
            <a href="AWS-Military-Aberdeen">
                <button class="btn carbtn carbtn8 carbtn8m">Aberdeen<span>(*19-Apr-21)</span></button>
            </a>
            <a href="AWS-Military-Portsmouth">
                <button class="btn carbtn carbtn9">Portsmouth<span>(*28-Jun-21)</span></button>
            </a>
            <a href="AWS-Military-Newcastle">
                <button class="btn carbtn carbtn10">Newcastle<span>(*20-Sep-21)</span></button>
            </a>
        </div>
        <h1 class="awstext1 awstext1m">Choose a city <span>(*Start date for cohort)</span></h1>
        <h1 class="awstext2 awstext2m text-center">You could be living here or are willing to relocate to the city of your choice
        </h1>
        <h1 class="miltext miltextm">If you're not <b>ex military</b> and looking for a <br>similar opportunity please <a href="aws-restart">Click here!</a></h1>
    </div>

    <div class="container smpara">
        <h2 class="text-center mt-4 font-weight-bold">About the program</h2>
        <p class="text-justify mt-3">
            Amazon Web Services (AWS) re/Start is a <b>free</b> skills development program that prepares learners for entry-level
            careers in the cloud.
            The program’s mission is to build local talent by providing AWS Cloud skills development and job
            opportunities to unemployed or underemployed populations. AWS re/Start is collaborating with Primed Talent
            Limited, a talent transformation organization for this program. Together, AWS re/Start and Primed Talent
            Limited are excited to help individuals launch a career in cloud computing.

        </p>
        <p class="text-justify">
            The 12-week program featuring real-world scenario-based learning, hands-on labs, and coursework is supported
            by professional mentors and accredited trainers. The program also provides structured interventions that
            help learners with resume and interview coaching to prepare for employer meetings and interviews to launch
            an entry-level cloud career.
        </p>
        <div class="container embed-container text-center mt-4 mb-5">
            <iframe src="https://www.youtube.com/embed/__J7xdX5F58" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
    <section style="background-color:#ebebeb; overflow:hidden">
        <div class="container smpara pt-5 pb-4">
            <h2 class="text-center mb-4 font-weight-bold">What’s in it for you ?</h2>


            <div class="row">
                <div class="col-lg-6 col-md-6 mx-auto col-sm-10  mb-3 p-3" style="border-radius:50px">
                    <div class="featcard shadow pt-4 pb-3" data-aos="fade-right">
                        <div class="row mt-4">
                            <div class="col-4 pr-0">
                                <img class="img-fluid mb-2 pl-2" src="Assets/Images/ft.png" alt="">
                            </div>
                            <div class="col-8">
                                <h5 class="q124"><b>Free Training on a Hot Skill</b></h5>
                                <p class="mb-0 q124">Yes! Training for in-demand cloud computing skills is absolutely
                                    free! Your first step to unlock an all-new career path in IT
                                </p>
                            </div>
                        </div>
                    </div>
                </div>





                <div class="col-lg-6 col-md-6 mx-auto col-sm-10  mb-3 p-3" style="border-radius:50px;">
                    <div class="featcard shadow pt-4 pb-3" data-aos="fade-left">
                        <div class="row">
                            <div class="col-4 pr-0">
                                <img class="img-fluid mb-2 mt-4 pl-2" src="Assets/Images/ml.png" alt="">
                            </div>
                            <div class="col-8">
                                <h5 class="q124 mt-4"><b>Real Practice</b></h5>
                                <p class="mb-0 q124">You’ll complete real-world scenario-based learning, hands-on labs,
                                    and coursework to prepare for a career in the cloud
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 mx-auto col-sm-10 mb-3 p-3 mx-auto" style="border-radius:50px;">
                    <div class="featcard shadow pt-4 pb-3" data-aos="fade-right">
                        <div class="row">
                            <div class="col-4 pr-0">
                                <img class="img-fluid mb-2 mt-4 pl-2" src="Assets/Images/gc.png" alt="">
                            </div>
                            <div class="col-8">
                                <h5 class="mt-4 q124"><b>Global Certification</b></h5>
                                <p class="mb-0 q124">On successful completion of the training, you’ll be eligible to
                                    take the <a target="_blank" href="https://aws.amazon.com/certification/certified-cloud-practitioner/"> AWS
                                        Cloud Practitioner</a> Certification exam
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 mx-auto col-sm-10 mb-3 p-3 mx-auto" style="border-radius:50px">
                    <div class="featcard shadow pt-4 pb-3" data-aos="fade-left">
                        <div class="row">
                            <div class="col-4 pr-0">
                                <img class="img-fluid mb-2 mt-4 pl-2" src="Assets/Images/po.png" alt="">
                            </div>
                            <div class="col-8">
                                <h5 class="q124 mt-3"><b>Placement Opportunities</b></h5>

                                <p class="mb-0 q124">We will work with you and help you with opportunities to get placed
                                    so that you can restart or start your career
                                </p>
                            </div>
                        </div>
                        <div id="tcpcourses"></div>
                    </div>
                </div>
            </div>


        </div>
    </section>
    <section>
        <div class="container mt-4">
            <h2 class="text-center font-weight-bold">Batch start date</h2>


            <table class="table table-hover mt-4">
                <thead class="thead-dark">
                    <tr>
                        <th>City</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            Dundee / Glasgow / Edinburgh / Aberdeen
                        </td>
                        <td>19-Apr-21 </td>
                    </tr>
                    <tr>
                        <td>Reading</td>
                        <td>16-Aug-21</td>
                    </tr>
                    <tr>
                        <td>Newcastle</td>
                        <td>17-May-21 </td>
                    </tr>
                    <tr>
                        <td>Portsmouth, Plymouth, Southampton, Yovill </td>
                        <td>28-Jun-21</td>
                    </tr>
                </tbody>
            </table>
            <h2 class="text-center font-weight-bold">How does it work?</h2>
            <ul class="progress-tracker progress-tracker--text progress-tracker--vertical progress-tracker--spaced">


                <li class="progress-step is-complete">
                    <span class="progress-marker pm1"><b>1</b></span>
                    <span class="progress-text">
                        <div class="info">
                            <h4 class="progress-title mb-4">Check your Eligibility</h4>
                            <p>
                                To be eligible for program, you need to fulfil these
                                requirements:
                            </p>
                            <ul class="ml-4">
                                <li>
                                    You are not in full time employment or are working regularly
                                    more than 16 hours per week
                                </li>
                                <li>You are currently not in education or training</li>
                                <li>You have the legal right to live and work in the UK</li>
                                <li>
                                    You are interested in a career in technology and are able to
                                    demonstrate the same
                                </li>
                                <li>
                                    You are available and ok to undergo training for 12
                                    consecutive weeks (Full days; Monday to Friday 9 AM to 5:30
                                    PM)
                                </li>
                                <li>You possess computing equipment and steady internet connection to undergo the
                                    training</li>
                                <li>
                                    You are ok to start working immediately post training should you find a job
                                    opportunity
                                </li>
                                <li>You are ex military</li>
                                <!-- <li>
                  You have a laptop/desk top with good internet access ( we’ll
                  keep this till physical classes can start)
                </li> -->
                            </ul>
                        </div>
                    </span>
                </li>

                <li class="progress-step is-complete">
                    <span class="progress-marker pm2"><b>2</b></span>
                    <span class="progress-text">
                        <div class="info">
                            <h4 class="progress-title">Register for the Programme</h4>
                            <a>
                                <button class="btn apnowbtn" data-toggle="modal" data-target="#formmodal">
                                    Apply now!
                                </button>
                            </a>
                        </div>
                    </span>
                </li>

                <li class="progress-step is-complete">
                    <span class="progress-marker pm3"><b>3</b></span>
                    <span class="progress-text">
                        <div class="info">
                            <h4 class="progress-title">
                                We will reach out to you and explain the next steps over a mail
                                or a call
                            </h4>
                        </div>
                    </span>
                </li>

            </ul>

        </div>
    </section>

    <div class="modal fade contmodal" id="formmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 100000000">
        <div class="modal-dialog modal-dialog-centered modal-dialog-cont" role="document">
            <div class="modal-content">
                <div class="modal-header mh-cont">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <br />
                <form class="cuform" action="awsprocess-military-edinburgh.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" data-form-email="true" value="" />
                    <div class="row row-sm-offset">
                        <div class="col-md-12 multi-horizontal nm" data-for="name">
                            <div class="form-group">
                                <label class="form-control-label mbr-fonts-style display-7" for="name-form1-2w">Name*</label>
                                <input type="text" class="form-control" name="name" data-form-field="Name" required id="name-form1-2w" />
                            </div>
                        </div>
                        <div class="col-md-12 multi-horizontal em" data-for="email">
                            <div class="form-group">
                                <label class="form-control-label mbr-fonts-style display-7" for="email-form1-2w">Email*</label>
                                <input type="email" class="form-control " name="email" data-form-field="Email" required id="email-form1-2w" />
                            </div>
                        </div>
                        <div class="col-md-12 multi-horizontal" data-for="phone">
                            <div class="form-group">
                                <label class="form-control-label mbr-fonts-style display-7" for="phone-form1-2w">Phone*</label>
                                <input type="tel" class="form-control " name="phone" data-form-field="Phone" id="phone-form1-2w" required />
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="years">Number of Years/Months of experience*</label>
                        <div class="row">
                            <div class="col">
                                <select class="form-control form-inline" name="years" required>
                                    <option value="" disabled selected hidden>Years*</option>
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    <option value="More than 10">More than 10</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="form-control form-inline" name="months" required>
                                    <option value="" disabled selected hidden>Months*</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ljr">Last job role*</label>
                        <input class="form-control" type="text" name="ljr" required />
                    </div>

                     <div class="form-group">
                        <label class="form-control-label mbr-fonts-style display-7" for="attachment">Upload resume*(Only pdf, jpg, jpeg, png, doc, docx formats are allowed)</label>
                        <input type="file" name="attachment" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label mbr-fonts-style display-7">How did you hear about us?*</label>
                        <select class="form-control" name="howhear" onchange="checkvalue(this.value)" required>
                            <option value="" disabled selected hidden>Please select</option>
                            <option value="Facebook">Facebook</option>
                            <option value="LinkedIn">LinkedIn</option>
                            <option value="Google Search">Google Search</option>
                            <option value="YouTube">YouTube</option>
                            <option value="Twitter">Twitter</option>
                            <option value="Others">Others</option>
                        </select>
                        <input class="form-control mt-3" type="text" placeholder="Please specify*" name="howother" id="howhearinp" />
                    </div>

                    <div class="form-group" data-for="message">
                        <label class="form-control-label mbr-fonts-style display-7" for="message-form1-2w">Message*</label>
                        <textarea type="text" class="form-control" name="message" rows="4" data-form-field="Message" id="message-form1-2w" required></textarea>
                    </div>

                    <span class="input-group-btn ml-1">
                        <button href="" type="submit" class="btn ml-0 btn-form display-4 sub-btn" name="btn-send">
                            SUBMIT
                        </button>
                    </span>
                </form>
            </div>
        </div>
    </div>


    <section class="skillsearned mb-5">
        <div class="container">
            <h2 class="font-weight-bold text-center">What skills will you learn during the 12 weeks?</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="main-timeline2">
                        <div class="timeline">
                            <span class="icon fa fa-globe"></span>
                            <span href="#" class="timeline-content">
                                <h3 class="title">Week 1 – Week 7</h3>
                                <p class="description">
                                    Focus on Core IT areas for a Support / Operations such as Linux, Networking,
                                    Security, Python Programming and Database
                                </p>
                            </span>
                        </div>
                        <div class="timeline">
                            <span class="icon fa fa-rocket"></span>
                            <span class="timeline-content">
                                <h3 class="title"> Week 7 – Week 9</h3>
                                <p class="description">
                                    Focus on AWS core services such as Cloud Economics, Global Infrastructure, Elastic
                                    Load Balancing, Amazon CloudWatch, Auto Scaling, Cloud Architecting & Security
                                </p>
                            </span>
                        </div>
                        <div class="timeline">
                            <span class="icon fa fa-briefcase"></span>
                            <span class="timeline-content">
                                <h3 class="title">Week 9 – Week 12</h3>
                                <p class="description">
                                    Deep dive into AWS services from an operational viewpoint such as
                                    Tooling-and-Automation, Computing-Servers, Scaling-and-Name-Resolution,
                                    Containers-and-Serverless, Networking, Monitoring-and-Security
                                </p>
                            </span>
                        </div>
                        <div class="timeline">
                            <span class="icon fa fa-mobile"></span>
                            <span class="timeline-content">
                                <h3 class="title">Employability Skills
                                </h3>
                                <p class="description">
                                    Focus on activities blending soft skills learnings with professional environment -
                                    like tools, processes and best practice exposure. Unified and immersive experience
                                    created for learners through a blend of technical and behavioral skills that could
                                    leverage the interview process
                                </p>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





    <div class="container faqhead">
        <h2 class="font-weight-bold text-center">FAQs</h2>
    </div>

    <div class="accordion awsaccordion mx-auto mt-5 mb-5" id="accordion2">
        <div class="card accard">
            <div class="card-header" id="headingOne">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        How much does this programme cost?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>

            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>The programme is free for all applicants.</p>
                </div>
            </div>
        </div>
        <div class="card accard">
            <div class="card-header" id="headingTwo">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        How can I apply for a programme?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>
            <div id="collapseTwo" class="collapse acollapse" aria-labelledby="headingTwo" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>
                        Navigate to the programme page and select the register your
                        interest button OR the apply button. If there is an option to
                        register your interest, this means that we are not currently
                        receiving applications and that we will make contact with you as
                        soon as programmes are open.
                    </p>
                </div>
            </div>
        </div>
        <div class="card accard">
            <div class="card-header" id="headingThree">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        My application is under review, how long is this going to take?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>
            <div id="collapseThree" class="collapse acollapse" aria-labelledby="headingThree" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>
                        Please note that it can take up to 2 weeks for your application to
                        move onto the next stage of the process. If you have not heard
                        back in 2 weeks then get in touch with us.
                    </p>
                </div>
            </div>
        </div>
        <div class="card accard">
            <div class="card-header" id="headingFour">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                        Why was my application rejected?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>
            <div id="collapseFour" class="collapse acollapse" aria-labelledby="headingFour" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>
                        Your application was rejected as you have not met one of our
                        programmes criteria’s OR not scored the minimum number of points
                        on a test in the application cycle. Please ensure that you review the eligibility criteria on
                        the Programme page. Common reasons for why you
                        may have been rejected are because on the application you have
                        selected an option that means you:<br />
                        • Do not live in the area<br />
                        • Are currently working over 16 hours per week<br />
                        • Will be in full-time education or training at the start of the
                        programme<br />
                        • Do not have the right to live and work in the UK<br />
                        • Are not available for the full duration of the programme<br />
                        • Are not able to start a job straight after the programme is
                        complete<br />
                        • Did not score the minimum number of points on one of our
                        tests/tasks to move onto the next stage
                    </p>
                </div>
            </div>
        </div>
        <div class="card accard">
            <div class="card-header" id="headingFive">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                        I don’t live in the UK, but I am interested – can I apply?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>
            <div id="collapseFive" class="collapse acollapse" aria-labelledby="headingFive" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>
                        Unfortunately, as of now this program is only for individuals who
                        can legally work in the UK
                    </p>
                </div>
            </div>
        </div>
        <div class="card accard">
            <div class="card-header" id="headingSix">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                        Am I guaranteed a job with this programme?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>
            <div id="collapseSix" class="collapse acollapse" aria-labelledby="headingSix" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>
                        After you have successfully completed our training, we provide placement assistance by helping
                        schedule interview(s) with hiring employer(s)
                    </p>
                </div>
            </div>
        </div>
        <div class="card accard">
            <div class="card-header" id="headingSeven">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                        Do I need any tech experience to be eligible for the programme?<i class="fa float-right accicon"></i>
                    </button>
                </h2>
            </div>
            <div id="collapseSeven" class="collapse acollapse" aria-labelledby="headingSeven" data-parent="#accordion2">
                <div class="card-body accbody">
                    <p>
                        No IT/Tech experience is required to be eligible for the programme.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div id="thankmodal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered thankmodal">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body"> <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h2 class="text-center mt-4 mb-3">Thank you for submitting the information.</h2>
                    <p class="text-center">You are very important to us, all information received will always remain
                        confidential. We’ll get
                        back to you very soon.</p>
                </div>
                <div class="modal-footer"></div>
            </div>

        </div>
    </div>

    <div id="errormodal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered thankmodal">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <h1 class="text-center">Please try again</h1>
                </div>
                <div class="modal-footer"></div>
            </div>

        </div>
    </div>

    <?php include "footer.html" ?>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 750,
        });
    </script>
    <script>
        $(document).ready(function() {
            if (window.location.href.indexOf('?success') != -1) {
                $('#thankmodal').modal('show');
            }
        });

        $(document).ready(function() {
            if (window.location.href.indexOf('?error') != -1) {
                $('#errormodal').modal('show');
            }
        });
    </script>
</body>

</html>